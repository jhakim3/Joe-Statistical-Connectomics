function [lnLH,pHatMat] = LikelihoodEstimation(adjacency,clusters,numClusters)
    m=numClusters;
    pHatMat=zeros(m,m);
    lnLH = 0;
    for i = 1:m
        for j=1:m
            
            sum = 0;
            
            for a=(clusters{i})
                for b=(clusters{j})
                    sum=sum+adjacency(a,b);
                end
            end
            blockSize=length(clusters{i}) * length(clusters{j});
            
            pHat=sum/blockSize;
            
            pHatMat(i,j)=pHat;
            
            %to avoid taking the ln(0), avoid pHat = 0 or 1
            if(pHat ~= 0)
                lnLH = lnLH + log(pHat)*(sum);
            end
            if(pHat ~= 1)
                lnLH = lnLH + log(1-pHat)*(blockSize-sum);
            end
            
        end
    end
    

end
