load('rats.mat')
ratGraphs = {rat1,rat2,rat3};

maxCluster=5;
nmc=100;

alphaList=ones(maxCluster-1,maxCluster-1,3);


tic
for n = 2:maxCluster %number of clusters in SBM for H0
    for m = 2:maxCluster %number of clusters in SBM for HA
        if(n ~= m)
            clusterList0={[],[],[]};
            clusterList1={[],[],[]};
            
            for g=1:3 %for each rat, form stochastic block models in h0 and h1
                
                clusterList0{g}=SpectralClustering(ratGraphs{g},n,2); %theta_hat_0
                clusterList1{g}=SpectralClustering(ratGraphs{g},m,2); %theta_hat_1
            end
            
            
            for g=1:3
                
                %Likelihoods are using ln(likelihood) because matlab does
                %not handle numbers of such low magnitude
                [LH_0real,pHatMat0] = LikelihoodEstimation(ratGraphs{g},clusterList0{g},n);
                [LH_1real,pHatMat1] = LikelihoodEstimation(ratGraphs{g},clusterList1{g},m);
                
                h0count = 0; %count of how many times L_h0 > L_h1
                
                for mc=1:nmc
                    %fprintf('%d,',mc)
                    A=zeros(size(ratGraphs{g})); %Generate a random graph based on h0
                    
                    for i = 1:n
                        for j=1:n
                            
                            for a=(clusterList0{g}{i})
                                for b=(clusterList0{g}{j})
                                    pHat=pHatMat0(i,j);
                                    
                                    A(a,b)=(rand<pHat);
                                end
                            end
                            
                            
                        end
                    end
                    
                    
                    [LH_0,~]=LikelihoodEstimation(A,clusterList0{g},n);
                    [LH_1,~]=LikelihoodEstimation(A,clusterList1{g},m);
                    
                    LH_0=abs(LH_0);
                    LH_1=abs(LH_1)-n*m*50;%heuristic measure of penalty applied
                    
                    h0count = h0count + (LH_0 > LH_1);
                end
                
                alpha = (h0count+1)/(nmc+1);
                alphaList(n,m,g)=alpha;
                
                
                
                %disp(['LH_0: ' num2str(LH_0) ' \tLH_1: ' num2str(LH_1)]);
                disp([num2str(alpha) ' alpha, for H0 = SBM_' num2str(n) ', HA = SBM_' num2str(m)])
            end
        end
    end
end

toc