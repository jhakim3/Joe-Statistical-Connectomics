
clear all;

XTime0 = [[125;100],[150;50]];
PTime0 = [[0;200],[0;200]];
sigma = 50;
nX = 200; %number of columns
nY = 200; %number of rows
xj = 1:nX; %x location of each column
yi = 1:nY; %y location of each row
[xij,yij] = meshgrid (xj,yi); % x,y location of each pixel

%% 3.1
flow(XTime0,PTime0,sigma,xij,yij);
PTime0 = [[100;-100],[-100;100]];
flow(XTime0,PTime0,sigma,xij,yij);

%% 3.2
%generate landmarks
X = XTime0;
%generate rotation variable
R = 30;%degrees;
%define target land marks by rotating X by rotation variable
for i = 1:length(X)
    magnitude = sqrt(X(1,i)^2 + X(2,i)^2);
    initialTheta = atand(X(2,i)/X(1,i)); 
    Y(1,i) = magnitude*cosd(initialTheta+R);
    Y(2,i) = magnitude*sind(initialTheta+R);
end

% for an initial guess, aim p in the right direction
p = (Y - X);
opt.MaxIter = 100; % don?t spend too much time optimizing
opt.Display = 'iter'; % print information about optimization
% optimize
p = fminsearch(@(p) sum(sum((flow(X,p,sigma,xij,yij) - Y).^2)),p,opt);
% display the target landmarks to see accuracy
[XTime1,phix,phiy] = flow(X,p,sigma,xij,yij); % get the final values
hold on;
scatter(Y(1,:),Y(2,:),'r')
hold off;
[a,b]=gradient(phix);
[c,d]=gradient(phiy);

for i = 1:200
    for j = 1:200
        grad(i,j)=det([d(i,j),c(i,j);b(i,j),a(i,j)]);
        
    end
end
grad(200,200)=-2;

figure
contourf(grad,200,'linestyle','none')
colorbar('ticks',[-2,0,2])

print('45_fig4','-dpng')
% for 30 degrees: p optimized is 0.021477 
% for 45 degrees: p optimized is 0.006509

%% 3.3
X=[[72;22.75],[73.75;22.9],[72.25;27],[72.5;28.5],[67.75;24.5],[67.9;26.5],[63.5;28],[64.5;29.25]];
Y=[[71.5;24],[73.5;23],[74.5;30],[77.5;32.25],[65.25;21],[65.25;23.5],[57.75;27.75],[59;29.25]];
sigma = 3; % cortex is about 3mm thick
opt.MaxIter = 1000; % it will take a while to optimize
opt.Display = 'iter'; % print information about optimization
x = linspace(60, 75, 20); % use a small grid if you want to speed up optimization
y = linspace(20, 35, 20);
[xij,yij] = meshgrid(x,y);
p = (Y - X); % for an initial guess, aim it in the right direction
p = fminsearch(@(p) sum(sum((flow(X,p,sigma,xij,yij) - Y).^2)),p,opt);

x = linspace(60, 75, 200); % use a big grid for the final display
y = linspace(20, 35, 200);
[xij,yij] = meshgrid(x,y);
[XTime1,phix,phiy] = flow(X,p,sigma,xij,yij); % get the final values
hold on;
scatter(Y(1,:),Y(2,:),'r')
hold off;
[a,b]=gradient(phix);
[c,d]=gradient(phiy);

for i = 1:200
    for j = 1:200
        grad(i,j)=det([d(i,j),c(i,j);b(i,j),a(i,j)]);
        
    end
end
grad(200,200)=- 0.0754;
figure
contourf(grad,200,'linestyle','none')
colorbar('ticks',[-2,0,2])
print('45_fig4','-dpng')


%5.798010 = poptimized