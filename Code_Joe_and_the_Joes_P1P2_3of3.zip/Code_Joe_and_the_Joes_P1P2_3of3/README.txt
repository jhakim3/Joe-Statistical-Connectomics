# Joe-and-the-Joes
Running the code:

-Make sure script.m, part1.m, part2.m, the 2analyze functions, 3estimate functions, patients 20 and 708, and estimateCO_v3.m are in the same directory
-Run script.m