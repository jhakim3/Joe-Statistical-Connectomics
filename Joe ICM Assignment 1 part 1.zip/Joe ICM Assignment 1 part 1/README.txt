# Joe-and-the-Joes
Running the code:

-Make sure script.m, part3.m, part4.m are in the same directory
-In script.m, specify the location of the ABP and N files in the local machine
-Run script.m